import angular from 'angular';
import '../additional_modules/ui-bootstrap-tpls-2.5.0-cust';
import 'bootstrap/dist/css/bootstrap.css';
import '../style/app.css';

import dropdownWithInput from './shared/dropdown-with-input/dropdown-with-input'
import vacDatepicker from './shared/vac-datepicker/vac-datepicker'

let app = () => {
  return {
    template: require('./app.html'),
    controller: 'AppCtrl',
    controllerAs: 'app'
  }
};

class AppCtrl {
  constructor() {
    this.url = 'https://github.com/preboot/angular-webpack';
  }
}

const MODULE_NAME = 'app';

angular.module(MODULE_NAME, ['ui.bootstrap'])
  .directive('app', app)
  .controller('AppCtrl', AppCtrl)
  .component('dropdownwithinput', dropdownWithInput)
  .component('vacdatepicker', vacDatepicker)
export default MODULE_NAME;

