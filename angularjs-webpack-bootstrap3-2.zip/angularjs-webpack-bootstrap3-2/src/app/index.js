console.log("index.js loaded")

import "../shared/dropdown-with-input/dropdown-with-input"