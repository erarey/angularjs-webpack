import template from "./vac-datepicker.html"

console.log("touched vac-datepicker")



export default {
    template,
    controllerAs: 'ctrl',
    controller: function () {
        console.log("vac-datepicker loaded")

        this.options = {
            //https://angular-ui.github.io/bootstrap/
            customClass: null,
            minDate: new Date(), // TODO: bind
            showWeeks: false,
            maxDate: new Date() + (30 * 6), // TODO: bind
            //minDate: null,
            maxMode: 'month',
            //minMode: 'day',
        }

        this.format = "MM/dd/yyyy"

        this.startDateCalPopup = false;
        this.endDateCalPopup = false;

        this.toggleStartDateCalPopup = () => this.startDateCalPopup = !this.startDateCalPopup
        this.toggleEndDateCalPopup = () => this.endDateCalPopup = !this.endDateCalPopup
        
        this.startDate = new Date()
        this.endDate = new Date()
        
        /*function getDayClass(data) {
            var date = data.date,
                mode = data.mode;
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < $scope.events.length; i++) {
                    var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return $scope.events[i].status;
                    }
                }
            }

            return '';
        }
        */

    }
}