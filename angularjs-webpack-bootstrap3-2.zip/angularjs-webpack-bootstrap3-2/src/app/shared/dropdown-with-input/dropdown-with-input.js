import template from "./dropdown-with-input.html"

console.log("touched dropdownwithinput")

/*
export default class dropdownWithInput {
    constructor() {

    this.templateURL = "./dropdown-with-input.html"
    this.controller = function() {
            console.log("dropdown-with-input loaded")
        }
    }
}
*/

export default {
        template,
        controller: function() {
            console.log("dropdown-with-input loaded")
        }
}
